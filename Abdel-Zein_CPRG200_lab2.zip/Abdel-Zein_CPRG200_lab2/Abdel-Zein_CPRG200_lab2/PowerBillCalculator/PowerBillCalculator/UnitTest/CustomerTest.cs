﻿//==================================================================================
// Author:       : Abdel Mohsen Zein
// Creat Date    : August 21, 2019
// Description   : A test code that tests the calculation of total power bill code depending on type of 
//                  customer and their kWh usage. OOSD 2019-CPRG 200
//==================================================================================
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CustomerData.Tests
//Methods to test the bill charge output for each customer type
{
    [TestClass()]
    public class CustomerTests
    {
        //2 test methods that calculate charge for Residential customer type
        [TestMethod()]
        public void TestResidential1()
        {
            //Arrange
            double expected = 89.2;

            //Act
            Customer aaa = new Customer(1, "Aaa", 'R', 1600, 0);
            double actual = aaa.CalculateCharge();

            //Assert
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void TestResidential2()
        {
            //Arrange
            double expected = 162;

            //Act
            Customer bbb = new Customer(1, "Bbb", 'R', 3000, 0);
            double actual = bbb.CalculateCharge();

            //Assert
            Assert.AreEqual(expected, actual);
        }

        //2 test methods that calculate charge for Commercial customer type
        [TestMethod()]
        public void TestCommercial1()
        {
            //Arrange
            double expected = 150;

            //Act
            Customer ccc = new Customer(1, "Store", 'C', 3000, 0);
            double actual = ccc.CalculateCharge();

            //Assert
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void TestCommercial2()
        {
            //Arrange
            double expected = 195;

            //Act
            Customer ckk = new Customer(1, "Restaurant", 'C', 4000, 0);
            double actual = ckk.CalculateCharge();

            //Assert
            Assert.AreEqual(expected, actual);
        }

        //4 methods that calculate charge for Industrial customer type
        [TestMethod()]
        public void TestIndustrialBothBelow1000()
        {
            //Arrange
            double expected = 116;

            //Act
            Customer acme = new Customer(1, "Acme", 'I', 500, 500);
            double actual = acme.CalculateCharge();

            //Assert
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void TestIndustrialPeakAbove1000()
        {
            //Arrange
            double expected = 181;

            //Act
            Customer summit = new Customer(1, "Summit", 'I', 2000, 0);
            double actual = summit.CalculateCharge();

            //Assert
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void TestIndustrialOffPeakAbove1000()
        {
            //Arrange
            double expected = 144;

            //Act
            Customer cap = new Customer(1, "Cap", 'I', 0, 2000);
            double actual = cap.CalculateCharge();

            //Assert
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void TestIndustrialBothAbove1000()
        {
            //Arrange
            double expected = 209;

            //Act
            Customer vertex = new Customer(1, "Vertex", 'I', 2000, 2000);
            double actual = vertex.CalculateCharge();

            //Assert
            Assert.AreEqual(expected, actual);
        }
    }
}

