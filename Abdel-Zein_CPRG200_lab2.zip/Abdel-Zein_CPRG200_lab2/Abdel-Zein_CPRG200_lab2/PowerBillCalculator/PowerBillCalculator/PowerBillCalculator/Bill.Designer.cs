﻿namespace PowerBillCalculator
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.customerLabel = new System.Windows.Forms.Label();
            this.inputLabel = new System.Windows.Forms.Label();
            this.customertypeComboBox = new System.Windows.Forms.ComboBox();
            this.inputTextbox = new System.Windows.Forms.TextBox();
            this.offPeakLabel = new System.Windows.Forms.Label();
            this.offPeakTextbox = new System.Windows.Forms.TextBox();
            this.calculateButton = new System.Windows.Forms.Button();
            this.chargeLabel = new System.Windows.Forms.Label();
            this.chargeTextbox = new System.Windows.Forms.TextBox();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.customernameTextbox = new System.Windows.Forms.TextBox();
            this.accountTextbox = new System.Windows.Forms.TextBox();
            this.customernameLabel = new System.Windows.Forms.Label();
            this.accountLabel = new System.Windows.Forms.Label();
            this.customerList = new System.Windows.Forms.ListBox();
            this.customerchargeGroupBox = new System.Windows.Forms.GroupBox();
            this.addButton = new System.Windows.Forms.Button();
            this.listsGroupBox = new System.Windows.Forms.GroupBox();
            this.customersLabel = new System.Windows.Forms.Label();
            this.customertotalLabel = new System.Windows.Forms.Label();
            this.industrialLabel = new System.Windows.Forms.Label();
            this.customersTextBox = new System.Windows.Forms.TextBox();
            this.commercialLabel = new System.Windows.Forms.Label();
            this.residentialLabel = new System.Windows.Forms.Label();
            this.customertotalTextbox = new System.Windows.Forms.TextBox();
            this.industrialTextbox = new System.Windows.Forms.TextBox();
            this.commercialTextbox = new System.Windows.Forms.TextBox();
            this.residentialTextBox = new System.Windows.Forms.TextBox();
            this.TitleLabel = new System.Windows.Forms.Label();
            this.customerchargeGroupBox.SuspendLayout();
            this.listsGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // customerLabel
            // 
            this.customerLabel.AutoSize = true;
            this.customerLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customerLabel.Location = new System.Drawing.Point(212, 37);
            this.customerLabel.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.customerLabel.Name = "customerLabel";
            this.customerLabel.Size = new System.Drawing.Size(100, 16);
            this.customerLabel.TabIndex = 1;
            this.customerLabel.Text = "Customer Type";
            // 
            // inputLabel
            // 
            this.inputLabel.AutoSize = true;
            this.inputLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inputLabel.Location = new System.Drawing.Point(10, 168);
            this.inputLabel.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.inputLabel.Name = "inputLabel";
            this.inputLabel.Size = new System.Drawing.Size(66, 16);
            this.inputLabel.TabIndex = 7;
            this.inputLabel.Text = "Input kWh";
            // 
            // customertypeComboBox
            // 
            this.customertypeComboBox.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.customertypeComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.customertypeComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customertypeComboBox.ForeColor = System.Drawing.Color.Black;
            this.customertypeComboBox.FormattingEnabled = true;
            this.customertypeComboBox.Items.AddRange(new object[] {
            "Residential",
            "Commercial",
            "Industrial"});
            this.customertypeComboBox.Location = new System.Drawing.Point(215, 65);
            this.customertypeComboBox.Margin = new System.Windows.Forms.Padding(5);
            this.customertypeComboBox.Name = "customertypeComboBox";
            this.customertypeComboBox.Size = new System.Drawing.Size(148, 25);
            this.customertypeComboBox.TabIndex = 3;
            this.customertypeComboBox.SelectedIndexChanged += new System.EventHandler(this.DropDown_SelectedIndexChanged);
            // 
            // inputTextbox
            // 
            this.inputTextbox.BackColor = System.Drawing.Color.White;
            this.inputTextbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inputTextbox.Location = new System.Drawing.Point(10, 189);
            this.inputTextbox.Margin = new System.Windows.Forms.Padding(5);
            this.inputTextbox.Name = "inputTextbox";
            this.inputTextbox.Size = new System.Drawing.Size(183, 22);
            this.inputTextbox.TabIndex = 9;
            // 
            // offPeakLabel
            // 
            this.offPeakLabel.AutoSize = true;
            this.offPeakLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.offPeakLabel.Location = new System.Drawing.Point(212, 168);
            this.offPeakLabel.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.offPeakLabel.Name = "offPeakLabel";
            this.offPeakLabel.Size = new System.Drawing.Size(90, 16);
            this.offPeakLabel.TabIndex = 8;
            this.offPeakLabel.Text = "Off-Peak kWh";
            // 
            // offPeakTextbox
            // 
            this.offPeakTextbox.BackColor = System.Drawing.Color.White;
            this.offPeakTextbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.offPeakTextbox.Location = new System.Drawing.Point(215, 189);
            this.offPeakTextbox.Margin = new System.Windows.Forms.Padding(5);
            this.offPeakTextbox.Name = "offPeakTextbox";
            this.offPeakTextbox.Size = new System.Drawing.Size(143, 22);
            this.offPeakTextbox.TabIndex = 10;
            // 
            // calculateButton
            // 
            this.calculateButton.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.calculateButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calculateButton.Location = new System.Drawing.Point(137, 320);
            this.calculateButton.Margin = new System.Windows.Forms.Padding(5);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(82, 35);
            this.calculateButton.TabIndex = 15;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = false;
            this.calculateButton.Click += new System.EventHandler(this.CalculateBtn_Click);
            // 
            // chargeLabel
            // 
            this.chargeLabel.AutoSize = true;
            this.chargeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chargeLabel.Location = new System.Drawing.Point(10, 232);
            this.chargeLabel.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.chargeLabel.Name = "chargeLabel";
            this.chargeLabel.Size = new System.Drawing.Size(90, 17);
            this.chargeLabel.TabIndex = 11;
            this.chargeLabel.Text = "Total Charge";
            this.chargeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // chargeTextbox
            // 
            this.chargeTextbox.BackColor = System.Drawing.Color.White;
            this.chargeTextbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chargeTextbox.Location = new System.Drawing.Point(10, 256);
            this.chargeTextbox.Margin = new System.Windows.Forms.Padding(5);
            this.chargeTextbox.Name = "chargeTextbox";
            this.chargeTextbox.ReadOnly = true;
            this.chargeTextbox.Size = new System.Drawing.Size(183, 22);
            this.chargeTextbox.TabIndex = 12;
            // 
            // clearButton
            // 
            this.clearButton.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.clearButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearButton.Location = new System.Drawing.Point(11, 320);
            this.clearButton.Margin = new System.Windows.Forms.Padding(5);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(89, 35);
            this.clearButton.TabIndex = 14;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = false;
            this.clearButton.Click += new System.EventHandler(this.ClearBtn_Click);
            // 
            // exitButton
            // 
            this.exitButton.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.exitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.exitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitButton.Location = new System.Drawing.Point(64, 320);
            this.exitButton.Margin = new System.Windows.Forms.Padding(5);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(150, 35);
            this.exitButton.TabIndex = 17;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = false;
            this.exitButton.Click += new System.EventHandler(this.ExitBtn_Click);
            // 
            // customernameTextbox
            // 
            this.customernameTextbox.BackColor = System.Drawing.Color.White;
            this.customernameTextbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customernameTextbox.Location = new System.Drawing.Point(11, 130);
            this.customernameTextbox.Margin = new System.Windows.Forms.Padding(4);
            this.customernameTextbox.Name = "customernameTextbox";
            this.customernameTextbox.Size = new System.Drawing.Size(348, 23);
            this.customernameTextbox.TabIndex = 6;
            // 
            // accountTextbox
            // 
            this.accountTextbox.BackColor = System.Drawing.Color.White;
            this.accountTextbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.accountTextbox.Location = new System.Drawing.Point(9, 67);
            this.accountTextbox.Margin = new System.Windows.Forms.Padding(4);
            this.accountTextbox.Name = "accountTextbox";
            this.accountTextbox.Size = new System.Drawing.Size(173, 23);
            this.accountTextbox.TabIndex = 2;
            // 
            // customernameLabel
            // 
            this.customernameLabel.AutoSize = true;
            this.customernameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customernameLabel.Location = new System.Drawing.Point(10, 99);
            this.customernameLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.customernameLabel.Name = "customernameLabel";
            this.customernameLabel.Size = new System.Drawing.Size(109, 17);
            this.customernameLabel.TabIndex = 4;
            this.customernameLabel.Text = "Customer Name";
            // 
            // accountLabel
            // 
            this.accountLabel.AutoSize = true;
            this.accountLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.accountLabel.Location = new System.Drawing.Point(7, 36);
            this.accountLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.accountLabel.Name = "accountLabel";
            this.accountLabel.Size = new System.Drawing.Size(177, 17);
            this.accountLabel.TabIndex = 0;
            this.accountLabel.Text = "Customer Account Number";
            // 
            // customerList
            // 
            this.customerList.BackColor = System.Drawing.Color.White;
            this.customerList.FormattingEnabled = true;
            this.customerList.ItemHeight = 17;
            this.customerList.Location = new System.Drawing.Point(10, 49);
            this.customerList.Name = "customerList";
            this.customerList.Size = new System.Drawing.Size(429, 242);
            this.customerList.TabIndex = 11;
            // 
            // customerchargeGroupBox
            // 
            this.customerchargeGroupBox.Controls.Add(this.addButton);
            this.customerchargeGroupBox.Controls.Add(this.accountLabel);
            this.customerchargeGroupBox.Controls.Add(this.customernameLabel);
            this.customerchargeGroupBox.Controls.Add(this.accountTextbox);
            this.customerchargeGroupBox.Controls.Add(this.customernameTextbox);
            this.customerchargeGroupBox.Controls.Add(this.clearButton);
            this.customerchargeGroupBox.Controls.Add(this.chargeTextbox);
            this.customerchargeGroupBox.Controls.Add(this.chargeLabel);
            this.customerchargeGroupBox.Controls.Add(this.calculateButton);
            this.customerchargeGroupBox.Controls.Add(this.offPeakTextbox);
            this.customerchargeGroupBox.Controls.Add(this.offPeakLabel);
            this.customerchargeGroupBox.Controls.Add(this.inputTextbox);
            this.customerchargeGroupBox.Controls.Add(this.customertypeComboBox);
            this.customerchargeGroupBox.Controls.Add(this.inputLabel);
            this.customerchargeGroupBox.Controls.Add(this.customerLabel);
            this.customerchargeGroupBox.ForeColor = System.Drawing.Color.Black;
            this.customerchargeGroupBox.Location = new System.Drawing.Point(8, 33);
            this.customerchargeGroupBox.Name = "customerchargeGroupBox";
            this.customerchargeGroupBox.Size = new System.Drawing.Size(375, 367);
            this.customerchargeGroupBox.TabIndex = 13;
            this.customerchargeGroupBox.TabStop = false;
            this.customerchargeGroupBox.Text = "Customer Charge";
            this.customerchargeGroupBox.Enter += new System.EventHandler(this.GroupBox1_Enter);
            // 
            // addButton
            // 
            this.addButton.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.addButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addButton.Location = new System.Drawing.Point(270, 320);
            this.addButton.Margin = new System.Windows.Forms.Padding(5);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(88, 35);
            this.addButton.TabIndex = 16;
            this.addButton.Text = "Add to List";
            this.addButton.UseVisualStyleBackColor = false;
            this.addButton.Click += new System.EventHandler(this.AddBtn_Click);
            // 
            // listsGroupBox
            // 
            this.listsGroupBox.Controls.Add(this.customersLabel);
            this.listsGroupBox.Controls.Add(this.customertotalLabel);
            this.listsGroupBox.Controls.Add(this.industrialLabel);
            this.listsGroupBox.Controls.Add(this.customersTextBox);
            this.listsGroupBox.Controls.Add(this.commercialLabel);
            this.listsGroupBox.Controls.Add(this.residentialLabel);
            this.listsGroupBox.Controls.Add(this.exitButton);
            this.listsGroupBox.Controls.Add(this.customertotalTextbox);
            this.listsGroupBox.Controls.Add(this.industrialTextbox);
            this.listsGroupBox.Controls.Add(this.commercialTextbox);
            this.listsGroupBox.Controls.Add(this.residentialTextBox);
            this.listsGroupBox.Controls.Add(this.customerList);
            this.listsGroupBox.ForeColor = System.Drawing.Color.Black;
            this.listsGroupBox.Location = new System.Drawing.Point(389, 33);
            this.listsGroupBox.Name = "listsGroupBox";
            this.listsGroupBox.Size = new System.Drawing.Size(583, 367);
            this.listsGroupBox.TabIndex = 14;
            this.listsGroupBox.TabStop = false;
            this.listsGroupBox.Text = "Customer List";
            // 
            // customersLabel
            // 
            this.customersLabel.AutoSize = true;
            this.customersLabel.Location = new System.Drawing.Point(319, 328);
            this.customersLabel.Name = "customersLabel";
            this.customersLabel.Size = new System.Drawing.Size(111, 17);
            this.customersLabel.TabIndex = 26;
            this.customersLabel.Text = "Total Customers";
            // 
            // customertotalLabel
            // 
            this.customertotalLabel.AutoSize = true;
            this.customertotalLabel.Location = new System.Drawing.Point(448, 232);
            this.customertotalLabel.Name = "customertotalLabel";
            this.customertotalLabel.Size = new System.Drawing.Size(111, 17);
            this.customertotalLabel.TabIndex = 24;
            this.customertotalLabel.Text = "Customers Total";
            // 
            // industrialLabel
            // 
            this.industrialLabel.AutoSize = true;
            this.industrialLabel.Location = new System.Drawing.Point(445, 167);
            this.industrialLabel.Name = "industrialLabel";
            this.industrialLabel.Size = new System.Drawing.Size(101, 17);
            this.industrialLabel.TabIndex = 22;
            this.industrialLabel.Text = "Industrial Total";
            // 
            // customersTextBox
            // 
            this.customersTextBox.BackColor = System.Drawing.Color.White;
            this.customersTextBox.Location = new System.Drawing.Point(436, 322);
            this.customersTextBox.Name = "customersTextBox";
            this.customersTextBox.ReadOnly = true;
            this.customersTextBox.Size = new System.Drawing.Size(126, 23);
            this.customersTextBox.TabIndex = 27;
            // 
            // commercialLabel
            // 
            this.commercialLabel.AutoSize = true;
            this.commercialLabel.Location = new System.Drawing.Point(445, 99);
            this.commercialLabel.Name = "commercialLabel";
            this.commercialLabel.Size = new System.Drawing.Size(117, 17);
            this.commercialLabel.TabIndex = 20;
            this.commercialLabel.Text = "Commercial Total";
            // 
            // residentialLabel
            // 
            this.residentialLabel.AutoSize = true;
            this.residentialLabel.Location = new System.Drawing.Point(445, 26);
            this.residentialLabel.Name = "residentialLabel";
            this.residentialLabel.Size = new System.Drawing.Size(114, 17);
            this.residentialLabel.TabIndex = 18;
            this.residentialLabel.Text = "Residential Total";
            // 
            // customertotalTextbox
            // 
            this.customertotalTextbox.BackColor = System.Drawing.Color.White;
            this.customertotalTextbox.Location = new System.Drawing.Point(448, 252);
            this.customertotalTextbox.Name = "customertotalTextbox";
            this.customertotalTextbox.ReadOnly = true;
            this.customertotalTextbox.Size = new System.Drawing.Size(114, 23);
            this.customertotalTextbox.TabIndex = 25;
            // 
            // industrialTextbox
            // 
            this.industrialTextbox.BackColor = System.Drawing.Color.White;
            this.industrialTextbox.Location = new System.Drawing.Point(448, 187);
            this.industrialTextbox.Name = "industrialTextbox";
            this.industrialTextbox.ReadOnly = true;
            this.industrialTextbox.Size = new System.Drawing.Size(114, 23);
            this.industrialTextbox.TabIndex = 23;
            // 
            // commercialTextbox
            // 
            this.commercialTextbox.BackColor = System.Drawing.Color.White;
            this.commercialTextbox.Location = new System.Drawing.Point(448, 122);
            this.commercialTextbox.Name = "commercialTextbox";
            this.commercialTextbox.ReadOnly = true;
            this.commercialTextbox.Size = new System.Drawing.Size(114, 23);
            this.commercialTextbox.TabIndex = 21;
            // 
            // residentialTextBox
            // 
            this.residentialTextBox.BackColor = System.Drawing.Color.White;
            this.residentialTextBox.Location = new System.Drawing.Point(448, 49);
            this.residentialTextBox.Name = "residentialTextBox";
            this.residentialTextBox.ReadOnly = true;
            this.residentialTextBox.Size = new System.Drawing.Size(114, 23);
            this.residentialTextBox.TabIndex = 19;
            // 
            // TitleLabel
            // 
            this.TitleLabel.BackColor = System.Drawing.SystemColors.Control;
            this.TitleLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TitleLabel.Location = new System.Drawing.Point(109, 1);
            this.TitleLabel.Name = "TitleLabel";
            this.TitleLabel.Size = new System.Drawing.Size(652, 29);
            this.TitleLabel.TabIndex = 15;
            this.TitleLabel.Text = "Y o u r   E l e c t r i c i t y   B i l l";
            this.TitleLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // MainForm
            // 
            this.AcceptButton = this.calculateButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.exitButton;
            this.ClientSize = new System.Drawing.Size(990, 412);
            this.Controls.Add(this.TitleLabel);
            this.Controls.Add(this.listsGroupBox);
            this.Controls.Add(this.customerchargeGroupBox);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Blue;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "City Power Bill Calculator";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.customerchargeGroupBox.ResumeLayout(false);
            this.customerchargeGroupBox.PerformLayout();
            this.listsGroupBox.ResumeLayout(false);
            this.listsGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label customerLabel;
        private System.Windows.Forms.Label inputLabel;
        private System.Windows.Forms.ComboBox customertypeComboBox;
        private System.Windows.Forms.TextBox inputTextbox;
        private System.Windows.Forms.Label offPeakLabel;
        private System.Windows.Forms.TextBox offPeakTextbox;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Label chargeLabel;
        private System.Windows.Forms.TextBox chargeTextbox;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.TextBox customernameTextbox;
        private System.Windows.Forms.TextBox accountTextbox;
        private System.Windows.Forms.Label customernameLabel;
        private System.Windows.Forms.Label accountLabel;
        private System.Windows.Forms.ListBox customerList;
        private System.Windows.Forms.GroupBox customerchargeGroupBox;
        private System.Windows.Forms.GroupBox listsGroupBox;
        private System.Windows.Forms.Label customertotalLabel;
        private System.Windows.Forms.Label industrialLabel;
        private System.Windows.Forms.Label commercialLabel;
        private System.Windows.Forms.Label residentialLabel;
        private System.Windows.Forms.TextBox customertotalTextbox;
        private System.Windows.Forms.TextBox industrialTextbox;
        private System.Windows.Forms.TextBox commercialTextbox;
        private System.Windows.Forms.TextBox residentialTextBox;
        private System.Windows.Forms.Button addButton;
        private System.Windows.Forms.Label customersLabel;
        private System.Windows.Forms.TextBox customersTextBox;
        private System.Windows.Forms.Label TitleLabel;
    }
}

