﻿//==================================================================================
// Author:       : Abdel Mohsen Zein
// Creat Date    : August 21, 2019
// Description   : A form that calculates total power bill depending on type of 
//                  customer and their kWh usage. OOSD 2019-CPRG 200
//==================================================================================
using CustomerData;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Windows.Forms;

namespace PowerBillCalculator
{
    public partial class MainForm : Form
    {
        List<Customer> AllCustomers; //make a list for customer objects
        int TotalCusts; //to count how may customers we have
        double AllTotal; //total bill charge for all customer types
        double TotalResidential; //total bill charge for residential customers
        double TotalCommercial; //total bill charge for commercial customers
        double TotalIndustrial; //total bill charge for industrial customers

        public MainForm()
        {
            InitializeComponent();
            chargeTextbox.ReadOnly = true;
        }

        private void MainForm_Load(object sender, EventArgs e)
        //Default settings when form opens
        {
            //hide the Off-Peak label and input text box by default
            offPeakTextbox.Visible = false;
            offPeakLabel.Visible = false;
            //default values in textboxes
            inputTextbox.Text = "";
            offPeakTextbox.Text = "";
            accountTextbox.Text = "";
            customernameTextbox.Text = "";
            //select Residential in combobox by default
            customertypeComboBox.SelectedItem = "Residential";
            //focus on Account number box on start
            accountTextbox.Select();

            //read customer info from txt file and save it on the customer list then display it on listbox
            AllCustomers = Customer.ReadCustomers();
            DisplayCustomers();
        }

        private void DisplayCustomers()
        //Displays all customer info and totals on the form
        {
            //reset list box and all output text boxes for totals
            customerList.Items.Clear();
            TotalCusts = 0;
            AllTotal = 0;
            TotalResidential = 0;
            TotalCommercial = 0;
            TotalIndustrial = 0;

            //add each customer to the list box and get all totals
            foreach (Customer c in AllCustomers)
            {
                customerList.Items.Add(c);
                TotalCusts++;
                AllTotal += c.Charge;

                //total charges for each customer type
                if (c.Type == 'R')
                {
                    TotalResidential += c.Charge;
                }
                else if (c.Type == 'C')
                {
                    TotalCommercial += c.Charge;
                }
                else
                {
                    TotalIndustrial += c.Charge;
                }
            }

            //output all values to form text boxes
            residentialTextBox.Text = TotalResidential.ToString("c");
            commercialTextbox.Text = TotalCommercial.ToString("c");
            industrialTextbox.Text = TotalIndustrial.ToString("c");
            customersTextBox.Text = TotalCusts.ToString();
            customertotalTextbox.Text = AllTotal.ToString("c");
        }

        private void DropDown_SelectedIndexChanged(object sender, EventArgs e)
        //Detects selection in combobox to show correct controls
        {
            if (customertypeComboBox.SelectedItem.ToString() == "Industrial")
            {
                /* if customer type is Industial, show the Off-Peak label and input text box,
                and change Input label text */
                inputTextbox.Clear();
                offPeakTextbox.Clear();
                chargeTextbox.Clear();
                accountTextbox.Clear();
                customernameTextbox.Clear();
                offPeakTextbox.Visible = true;
                offPeakLabel.Visible = true;
                inputLabel.Text = " Input Peak-Hours kWh";
            }
            else
            {
                /* otherwise, if customer type is Residential or Commercial,
                hide the Off-peak label and input text box, and change Input label text */
                inputTextbox.Clear();
                offPeakTextbox.Clear();
                chargeTextbox.Clear();
                accountTextbox.Clear();
                customernameTextbox.Clear();
                offPeakTextbox.Visible = false;
                offPeakLabel.Visible = false;
                inputLabel.Text = "Input kWh";
            }

            //focus on Input box
            inputTextbox.Select();
        }

        public void CalculateBtn_Click(object sender, EventArgs e)
        /* Calculates the total bill, and shows result in Result text box
           Can also be triggered when Enter key is pressed */
        {
            //validate inputs before assigning then make new customer

            int acct = IsInt(accountTextbox);
            string name = IsEmpty(customernameTextbox);
            double kwh = IsWholePositive(inputTextbox);
            double offpeak = 0;  // For the added textbox OffPeakBoc, In case of "Industrial" 
            if (customertypeComboBox.SelectedItem.ToString() == "Industrial")
            {
                offpeak = IsWholePositive(offPeakTextbox);
            }

            char type = TypeToChar();
            Customer newCust = new Customer(acct, name, type, kwh, offpeak);

            //total bill
            double Total = newCust.CalculateCharge();

            //convert result to string and show it in ResultBox as currency
            chargeTextbox.Text = Total.ToString("c");
        }

        private void AddBtn_Click(object sender, EventArgs e)
        //Adds new customer to listbox and writes it on txt file
        {
            //validate inputs before assigning then make new customer
            int acct = IsInt(accountTextbox);
            string name = IsEmpty(customernameTextbox);
            double kwh = IsWholePositive(inputTextbox);
            double offpeak = 0;  // For the added textbox OffPeakBoc, In case of "Industrial" 
            if (customertypeComboBox.SelectedItem.ToString() == "Industrial")
            {
                offpeak = IsWholePositive(offPeakTextbox);
            }
            double charge = double.Parse(chargeTextbox.Text, NumberStyles.Currency);
            char type = TypeToChar();
            Customer newCust = new Customer(acct, name, type, kwh, offpeak);
            newCust.Charge = charge;

            AllCustomers.Add(newCust); //add to the list
            DisplayCustomers(); //redo list box
            newCust.SaveCustomers(AllCustomers); //save info to txt file
        }

        public char TypeToChar()
        //Converts ComboBox selection to char
        {
            if (customertypeComboBox.SelectedItem.ToString() == "Residential")
            {
                return 'R';
            }
            else if (customertypeComboBox.SelectedItem.ToString() == "Commercial")
            {
                return 'C';
            }
            else
            {
                return 'I';
            }
        }

        private void ClearBtn_Click(object sender, EventArgs e)
        //Clears the current input(s) and output
        {
            //resets to default settings as when form loads
            inputTextbox.Text = "";
            offPeakTextbox.Text = "";
            accountTextbox.Text = "";
            customernameTextbox.Text = "";
            customertypeComboBox.SelectedItem = "Residential";
            accountTextbox.Select();
            chargeTextbox.Text = "";
        }

        private void ExitBtn_Click(object sender, EventArgs e)
        //Closes the form, can also be triggered when Esc key is pressed
        {
            this.Close();
        }

        public double IsWholePositive(TextBox txtbox)
        /* Validates if input text box is not empty and if it's a whole positive number
        if not, return 0, if yes, return the value from the input text box
        then assign the return value to the input variable */
        {
            //if InputBox is empty or if input is not a whole positive number
            if (txtbox.Text == "" || (Convert.ToDouble(txtbox.Text) < 0) || (Convert.ToDouble(txtbox.Text) % 1 != 0))
            {
                MessageBox.Show("Input kWh needs a whole positive number from 0.");
                //assign 0 in the input box and input variable
                txtbox.Text = "0";
                //focus on the box with the invalid value
                txtbox.SelectAll();
                return 0;
            }
            else
            {
                //assign the valid positive number in the input variable
                return Convert.ToDouble(txtbox.Text);
            }
        }

        public int IsInt(TextBox txtbox)
        /* Validates if input text box is not empty and if it's a positive integer
         if not, return 0, if yes, return the value from the input text box
          then assign the return value to the input variable */
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(accountTextbox.Text, "[^0-9]"))
            {
                MessageBox.Show("Account Number needs a positive integer from 0.");
                //assign 0 in the input box and input variable
                txtbox.Text = "0";
                //focus on the box with the invalid value
                txtbox.SelectAll();
                return 0;
            }
            else
            {
                //assign the valid positive integer in the input variable
                return Convert.ToInt32(txtbox.Text);
            }

        }

        public string IsEmpty(TextBox txtbox)
        // Validates if input text box is not empty
        {
            if (txtbox.Text == "")
            {
                MessageBox.Show("Customer Name needs to be filled");
                //focus on the box with the invalid value
                txtbox.SelectAll();
                return "";
            }
            else
            {
                return txtbox.Text;
            }
        }

        private void GroupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}